@extends('layout')
@section('detailpembelian','active')
@section('content')
<!-- Datatable start -->
<div class="card-box mb-30">
    <div class="row mb-5">
        <div class="col-md-12 mb-5">
            <div class="pd-20">
                <h4 class="text-blue h4">Data Detail Pembelian</h4>
                <button class="btn btn-primary">
                    <a href="{{route('pembelian.index')}}" style="color:#FFF">Kembali</a>
                </button>
                <div class="float-right">
                    <button class="btn btn-primary">
                        <a href="/form_detailpembelian/{{$id}}" style="color:#FFF">Tambah Data</a>
                    </button>
                    <button class="btn btn-primary">
                        <a href="{{route('inventory.export')}}" style="color:#FFF">Export</a>
                    </button>
                    <!-- Button trigger modal -->
                    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
                        Import
                    </button>
                </div>
                <!-- Modal -->
                <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <form action="{{route('inventory.import')}}" enctype="multipart/form-data" method="post">
                                @csrf
                                <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLabel">Masukan Data</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    <input type="file" name="file" id="">
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                    <button type="submit" class="btn btn-primary">Import</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="pb-20">
                <table class="data-table table">
                    <thead>
                        <tr>
                            <th>Id Pembelian Pembelian</th>
                            <th class="datatable-nosort">Id Pembelian</th>
                            <th class="datatable-nosort">No Inv</th>
                            <th class="datatable-nosort">Harga Satuan</th>
                            <th class="datatable-nosort">Jumlah Pembelian</th>
                            <th class="datatable-nosort">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($detailpembelian as $row)
                        <tr>
                            <td>{{ $row->id_detail_pembelian}}</td>
                            <td>{{ $row->id_pembelian}}</td>
                            <td>{{ $row->no_inv}}</td>
                            <td>{{ $row->harga_satuan}}</td>
                            <td>{{ $row->jumlah_pembelian}}</td>
                            <td>
                                <div class="dropdown">
                                    <a class="btn btn-link font-24 p-0 line-height-1 no-arrow dropdown-toggle" href="#" role="button" data-toggle="dropdown">
                                        <i class="dw dw-more"></i>
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-right dropdown-menu-icon-list">
                                        <a class="dropdown-item" href="/form_detailpembelian/edit/{{$row->id_detail_pembelian}}"><i class="dw dw-edit2"></i> Edit</a>
                                        <a class="dropdown-item" href="/form_detailpembelian/hapus/{{$row->id_detail_pembelian}}"><i class="dw dw-delete-3"></i> Delete</a>
                                    </div>
                                </div>
                            </td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<!-- Datatable End -->
@endsection
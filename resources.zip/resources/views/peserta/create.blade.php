@extends('layout')
@section('peserta','active')
@section('content')
<!-- Default Basic Forms Start -->
<div class="pd-20 card-box mb-30">
    <div class="clearfix">
        <div class="pull-left">
            <h4 class="text-blue h4">Form Peserta</h4>
            <p class="mb-30">Tambahkan Data Peserta Baru </p>
        </div>
    </div>
    <form action="/peserta" method="post" enctype="multipart/form-data">
        {{ csrf_field() }}
        <div class="form-group row">
            <label class="col-sm-12 col-md-2 col-form-label">Id Peserta</label>
            <div class="col-sm-12 col-md-10">
                <input class="form-control" type="text" name="id_peserta">
            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-12 col-md-2 col-form-label">Username</label>
            <div class="col-sm-12 col-md-10">
                <input class="form-control" type="text" name="username">
            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-12 col-md-2 col-form-label">Password</label>
            <div class="col-sm-12 col-md-10">
                <input class="form-control" type="text" name="password">
            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-12 col-md-2 col-form-label">Nama Lengkap</label>
            <div class="col-sm-12 col-md-10">
                <input class="form-control" type="text" name="nama">
            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-12 col-md-2 col-form-label">Tipe Training</label>
            <div class="col-sm-12 col-md-10">
                <select class=" form-control" name="jenis_training">
                    <option value="BST">Basic Safety Training (BST)</option>
                    ...
                    <option value="SCRB">Survival Craft and Rescue Boat (SCRB)</option>
                    ...
                    <option value="MFA">Medical First Aid Training (MFA)</option>
                    ...
                    <option value="MC">Medical Care On Board Ship Training (MC)</option>
                    ...
                    <option value="SAT">Security Awareness Training (SAT)</option>
                    ...
                    <option value="SATSDSD">Security Training for Seafarer with Designated Security Duties Program (SATSDSD)</option>
                    ...
                    <option value="BSTKLM">Basic Safety Training Kapal Layar Motor (BST - KLM)</option>
                    ...
                    <option value="AFF">Advanced Fire Fighting Training (AFF)</option>
                    ...
                    <option value="CMHBT">Crisis Management and Human Behaviour Training (CMHBT)</option>
                    ...
                    <option value="CMT">Crowd Management Training (CMT)</option>
                </select>
            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-12 col-md-2 col-form-label">Tanggal Lahir</label>
            <div class="col-sm-12 col-md-10">
                <input class="form-control date-picker" type=date name="tanggal_lahir">
            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-12 col-md-2 col-form-label">Tempat lahir</label>
            <div class="col-sm-12 col-md-10">
                <input class="form-control" type="text" name="tempat_lahir">
            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-12 col-md-2 col-form-label">Alamat Rumah</label>
            <div class="col-sm-12 col-md-10">
                <input class="form-control" type="text" name="alamat">
            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-12 col-md-2 col-form-label">Telepon Rumah</label>
            <div class="col-sm-12 col-md-10">
                <input class="form-control" type="text" name="tlp_rumah">
            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-12 col-md-2 col-form-label">Telepon Mobile</label>
            <div class="col-sm-12 col-md-10">
                <input class="form-control" type="text" name="tlp_mobile">
            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-12 col-md-2 col-form-label">Nomer Blanko</label>
            <div class="col-sm-12 col-md-10">
                <input class="form-control" type="text" name="blanko">
            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-12 col-md-2 col-form-label">Nomer Sertifikat</label>
            <div class="col-sm-12 col-md-10">
                <input class="form-control" type="text" name="sertifikat">
            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-12 col-md-2 col-form-label">Jenis Sertifikat</label>
            <div class="col-sm-12 col-md-10">
                <select class="js-example-basic-single" name="jenis_sertifikat">
                    <option value="COP">COP</option>
                    ...
                    <option value="COC">COC</option>
                </select>
            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-12 col-md-2 col-form-label">Status</label>
            <div class="col-sm-12 col-md-10">
                <input class="form-control" type="text" name="status">
            </div>
        </div>
        <button type="submit" class="btn btn-primary btn-lg btn-block">Submit</button>
    </form>
</div>
<!-- Default Basic Forms End -->
@endsection
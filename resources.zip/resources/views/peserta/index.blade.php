@extends('layout')
@section('peserta','active')
@section('content')
<!-- Datatable start -->
<div class="card-box mb-30">
    <div class="pd-20">
        <h4 class="text-blue h4">Data Peserta</h4>
        <a class="btn btn-dark" href="peserta/create">Create File </a>
        <button class="btn btn-primary">
            <a href="{{route('peserta.export')}}" style="color:#FFF">Export</a>
        </button>
        <!-- Button trigger modal -->
        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
            Import
        </button>

        <!-- Modal -->
        <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <form action="{{route('peserta.import')}}" enctype="multipart/form-data" method="post">
                        @csrf
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Masukkan Data</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <input type="file" name="file" id="">
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Import</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <div class="pb-20">
        <table class="data-table table">
            <thead>
                <tr>
                    <th>Id Peserta</th>
                    <th class="datatable-nosort">Name</th>
                    <th class="datatable-nosort">Username</th>
                    <th class="datatable-nosort">Password</th>
                    <th class="datatable-nosort">Tipe Training</th>
                    <th class="datatable-nosort">Tanggal Lahir</th>
                    <th class="datatable-nosort">Tempat Lahir</th>
                    <th class="datatable-nosort">Alamat Rumah</th>
                    <th class="datatable-nosort">Telepon Rumah</th>
                    <th class="datatable-nosort">Telepon Mobile</th>
                    <th class="datatable-nosort">Nomer Blanko</th>
                    <th class="datatable-nosort">Nomer Sertifikat</th>
                    <th class="datatable-nosort">Jenis Sertifikat</th>
                    <th class="datatable-nosort">Status</th>
                    <th class="datatable-nosort">Created at</th>
                    <th class="datatable-nosort">Log Activity</th>
                    <th class="datatable-nosort">Action</th>
                </tr>
            </thead>
            <tbody>
                @foreach($peserta as $row)
                <tr>
                    <td>{{ $row->id_peserta}}</td>
                    <td>{{ $row->username}}</td>
                    <td>{{ $row->password}}</td>
                    <td>{{ $row->nama_peserta}}</td>
                    <td>{{ $row->kode_diklat}}</td>
                    <td>{{ $row->tanggal_lahir}}</td>
                    <td>{{ $row->tempat_lahir}}</td>
                    <td>{{ $row->alamat}}</td>
                    <td>{{ $row->telpon_rumah}}</td>
                    <td>{{ $row->telpon_mobile}}</td>
                    <td>{{ $row->nomer_blanko}}</td>
                    <td>{{ $row->nomer_sertifikat}}</td>
                    <td>{{ $row->jenis_sertifikat}}</td>
                    <td>{{ $row->status}}</td>
                    <td>{{ $row->created_at}}</td>
                    <td>{{ $row->update_by}}</td>
                    <td>
                        <div class="dropdown">
                            <a class="btn btn-link font-24 p-0 line-height-1 no-arrow dropdown-toggle" href="#" role="button" data-toggle="dropdown">
                                <i class="dw dw-more"></i>
                            </a>
                            <div class="dropdown-menu dropdown-menu-right dropdown-menu-icon-list">
                                <a class="dropdown-item" href="/peserta/{{$row->id_peserta}}/edit"><i class="dw dw-edit2"></i> Edit</a>
                            </div>
                        </div>
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>
</div>
<!-- Datatable End -->
@endsection
@extends('layout')
@section('kelas','active')
@section('content')
<!-- Datatable start -->
<div class="card-box mb-30">
    <div class="pd-20">
        <h4 class="text-blue h4">Data Kelas Peserta</h4>
        <a class="btn btn-dark" href="kelas/create">Create File </a>
    </div>
    <div class="pb-20">
        <table class="data-table-export table">
            <thead>
                <tr>
                    <th>Kode Kelas</th>
                    <th class="datatable-nosort">Nama Diklat</th>
                    <th class="datatable-nosort">Id Kelas</th>
                    <th class="datatable-nosort">Nama Kelas</th>
                    <th class="datatable-nosort">Nama Peserta</th>
                    <th class="datatable-nosort">Update by</th>
                    <th class="datatable-nosort">Action</th>
                </tr>
            </thead>
            <tbody>
                @foreach($detail_kelas as $row)
                <tr>
                    <td>{{ $row->id_detail_kelas}}</td>
                    <td>{{ $row->nama_diklat}}</td>
                    <td>{{ $row->id_kelas}}</td>
                    <td>{{ $row->nama_kelas}}</td>
                    <td>{{ $row->nama_peserta}}</td>
                    <td>{{ $row->update_by}}</td>
                    <td>
                        <div class="dropdown">
                            <a class="btn btn-link font-24 p-0 line-height-1 no-arrow dropdown-toggle" href="#" role="button" data-toggle="dropdown">
                                <i class="dw dw-more"></i>
                            </a>
                            <div class="dropdown-menu dropdown-menu-right dropdown-menu-icon-list">
                                <a class="dropdown-item" href="/kelas/{{$row->id_detail_kelas}}/edit"><i class="dw dw-edit2"></i>Edit</a>
                                <form action="kelas/{{$row->id_detail_kelas}}" method="post">
                                    @csrf
                                    @method('delete')
                                    <button class="dropdown-item"><i class="dw dw-delete-3"></i>Delete</button>
                                </form>
                            </div>
                        </div>
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>
</div>
<!-- Datatable End -->
@endsection
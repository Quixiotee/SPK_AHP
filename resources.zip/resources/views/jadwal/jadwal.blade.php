@extends('layout')
@section('jadwal','active')
@section('content')
<!-- Datatable start -->
<div class="card-box mb-30">
    <div class="pd-20">
        <h4 class="text-blue h4">Jadwal</h4>
        <a class="btn btn-dark" href="jadwal/create">Create File </a>
    </div>
    <div class="pb-20">
        <table class="data-table-export table">
            <thead>
                <tr>
                    <th>Id Jadwal</th>
                    <th class="datatable-nosort">Id Kelas</th>
                    <th class="datatable-nosort">Nama Kelas</th>
                    <th class="datatable-nosort">Id Instruktur</th>
                    <th class="datatable-nosort">Nama Instruktur</th>
                    <th class="datatable-nosort">Log Activity</th>
                    <th class="datatable-nosort">Action</th>
                </tr>
            </thead>
            <tbody>
                @foreach($jadwal as $row)
                <tr>
                    <td>{{ $row->id_jadwal}}</td>
                    <td>{{ $row->kode_kelas}}</td>
                    <td>{{ $row->nama_kelas}}</td>
                    <td>{{ $row->id_instruktur}}</td>
                    <td>{{ $row->Nama}}</td>
                    <td>{{ $row->update_by}}</td>
                    <td>
                        <div class="dropdown">
                            <a class="btn btn-link font-24 p-0 line-height-1 no-arrow dropdown-toggle" href="#" role="button" data-toggle="dropdown">
                                <i class="dw dw-more"></i>
                            </a>
                            <div class="dropdown-menu dropdown-menu-right dropdown-menu-icon-list">
                            <a class="dropdown-item" href="/jadwal/{{$row->id_jadwal}}/edit"><i class="dw dw-edit2"></i> Edit</a>
								<form action="jadwal/{{$row->id_jadwal}}" method="post">
									@csrf
									@method('delete')
									<button class="dropdown-item"><i class="dw dw-delete-3"></i> Delete</button>
								</form>
                            </div>
                        </div>
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>
</div>
<!-- Datatable End -->
@endsection
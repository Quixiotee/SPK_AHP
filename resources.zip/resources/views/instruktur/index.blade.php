@extends('layout')
@section('instruktur','active')
@section('content')
<!-- Datatable start -->
<div class="card-box mb-30">
	<div class="pd-20">
		<h4 class="text-blue h4">Data Instruktur</h4>
		<a class="btn btn-dark" href="instruktur/create">Create File </a>
		<button class="btn btn-primary">
			<a href="{{route('instruktur.export')}}" style="color:#FFF">Export</a>
		</button>
		<!-- Button trigger modal -->
		<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
			Import
		</button>

		<!-- Modal -->
		<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
			<div class="modal-dialog" role="document">
				<div class="modal-content">
					<form action="{{route('instruktur.import')}}" enctype="multipart/form-data" method="post">
						@csrf
						<div class="modal-header">
							<h5 class="modal-title" id="exampleModalLabel">Masukkan Data</h5>
							<button type="button" class="close" data-dismiss="modal" aria-label="Close">
								<span aria-hidden="true">&times;</span>
							</button>
						</div>
						<div class="modal-body">
							<input type="file" name="file" id="">
						</div>
						<div class="modal-footer">
							<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
							<button type="submit" class="btn btn-primary">Import</button>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
	<div class="pb-20">
		<table class="data-table table">
			<thead>
				<tr>
					<th>Id Instruktur</th>
					<th class="datatable-nosort">Name</th>
					<th class="datatable-nosort">Pendidikan Formal</th>
					<th class="datatable-nosort">Pendidikan Informal</th>
					<th class="datatable-nosort">Sertifikat 6.09</th>
					<th class="datatable-nosort">Sertifikat 3.12</th>
					<th class="datatable-nosort">Sertifikat 6.10</th>
					<th class="datatable-nosort">Program Diklat 1</th>
					<th class="datatable-nosort">Program Diklat 2</th>
					<th class="datatable-nosort">Log Activity</th>
					<th class="datatable-nosort">Action</th>
				</tr>
			</thead>
			<tbody>
				@foreach($instruktur as $row)
				<tr>
					<td>{{ $row->id_instruktur}}</td>
					<td>{{ $row->Nama}}</td>
					<td>{{ $row->P_Formal}}</td>
					<td>{{ $row->P_Informal}}</td>
					<td>{{ $row->S_1}}</td>
					<td>{{ $row->S_2}}</td>
					<td>{{ $row->S_3}}</td>
					<td>{{ $row->Diklat_1}}</td>
					<td>{{ $row->Diklat_2}}</td>
					<td>{{ $row->update_by}}</td>
					<td>
						<div class="dropdown">
							<a class="btn btn-link font-24 p-0 line-height-1 no-arrow dropdown-toggle" href="#" role="button" data-toggle="dropdown">
								<i class="dw dw-more"></i>
							</a>
							<div class="dropdown-menu dropdown-menu-right dropdown-menu-icon-list">
								<a class="dropdown-item" href="/instruktur/{{$row->id_instruktur}}/edit"><i class="dw dw-edit2"></i> Edit</a>
							</div>
						</div>
					</td>
				</tr>
				@endforeach
			</tbody>
		</table>
	</div>
</div>
<!-- Datatable End -->
@endsection
@extends('layout')
@section('instruktur','active')
@section('content')
<!-- Default Basic Forms Start -->
<div class="pd-20 card-box mb-30">
    <div class="clearfix">
        <div class="pull-left">
            <h4 class="text-blue h4">Data Instruktur</h4>
            <p class="mb-30">Tambahkan Data Instruktur</p>
        </div>
    </div>
    <form action="/instruktur" method="post" enctype="multipart/form-data">
        {{ csrf_field() }}
        <div class="form-group row">
            <label class="col-sm-12 col-md-2 col-form-label">Id Instruktur</label>
            <div class="col-sm-12 col-md-10">
                <input class="form-control" type="number" name="id_instruktur">
            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-12 col-md-2 col-form-label">Nama Lengkap</label>
            <div class="col-sm-12 col-md-10">
                <input class="form-control" type="text" name="Nama">
            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-12 col-md-2 col-form-label">Pendidikan Formal</label>
            <div class="col-sm-12 col-md-10">
                <input class="form-control" type="text" name="P_Formal">
            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-12 col-md-2 col-form-label">Pendidikan Informal</label>
            <div class="col-sm-12 col-md-10">
                <input class="form-control" type="text" name="P_Informal">
            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-12 col-md-2 col-form-label">Sertifikat 6.09</label>
            <div class="col-sm-12 col-md-10">
                <input class="form-control" type="text" name="S_1">
            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-12 col-md-2 col-form-label">Sertifikat 3.12</label>
            <div class="col-sm-12 col-md-10">
                <input class="form-control" type="text" name="S_2">
            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-12 col-md-2 col-form-label">Sertifikat 6.10</label>
            <div class="col-sm-12 col-md-10">
                <input class="form-control" type="text" name="S_3">
            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-12 col-md-2 col-form-label">Diklat 1</label>
            <div class="col-sm-12 col-md-10">
                <select class=" form-control" name="jenis_training">
                    <option value="BST">Basic Safety Training (BST)</option>
                    ...
                    <option value="SCRB">Survival Craft and Rescue Boat (SCRB)</option>
                    ...
                    <option value="MFA">Medical First Aid Training (MFA)</option>
                    ...
                    <option value="MC">Medical Care On Board Ship Training (MC)</option>
                    ...
                    <option value="SAT">Security Awareness Training (SAT)</option>
                    ...
                    <option value="SATSDSD">Security Training for Seafarer with Designated Security Duties Program (SATSDSD)</option>
                    ...
                    <option value="BSTKLM">Basic Safety Training Kapal Layar Motor (BST - KLM)</option>
                    ...
                    <option value="AFF">Advanced Fire Fighting Training (AFF)</option>
                    ...
                    <option value="CMHBT">Crisis Management and Human Behaviour Training (CMHBT)</option>
                    ...
                    <option value="CMT">Crowd Management Training (CMT)</option>
                </select>
            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-12 col-md-2 col-form-label">Diklat 2</label>
            <div class="col-sm-12 col-md-10">
                <select class=" form-control" name="jenis_training">
                    <option value="BST">Basic Safety Training (BST)</option>
                    ...
                    <option value="SCRB">Survival Craft and Rescue Boat (SCRB)</option>
                    ...
                    <option value="MFA">Medical First Aid Training (MFA)</option>
                    ...
                    <option value="MC">Medical Care On Board Ship Training (MC)</option>
                    ...
                    <option value="SAT">Security Awareness Training (SAT)</option>
                    ...
                    <option value="SATSDSD">Security Training for Seafarer with Designated Security Duties Program (SATSDSD)</option>
                    ...
                    <option value="BSTKLM">Basic Safety Training Kapal Layar Motor (BST - KLM)</option>
                    ...
                    <option value="AFF">Advanced Fire Fighting Training (AFF)</option>
                    ...
                    <option value="CMHBT">Crisis Management and Human Behaviour Training (CMHBT)</option>
                    ...
                    <option value="CMT">Crowd Management Training (CMT)</option>
                </select>
            </div>
        </div>
        <button type="submit" class="btn btn-primary btn-lg btn-block">Submit</button>
    </form>
</div>
<!-- Default Basic Forms End -->
@endsection
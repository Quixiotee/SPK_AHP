@extends('layout')
@section('inventory','active')
@section('content')
<!-- Default Basic Forms Start -->
<div class="pd-20 card-box mb-30">
    <div class="clearfix">
        <div class="pull-left">
            <h4 class="text-blue h4">Form Inventory</h4>
            <p class="mb-30">Tambahkan data Inventory </p>
        </div>
    </div>
    <form action="/form_inventory/update/{{ $inventory->no_inv }}" method="post" enctype="multipart/form-data">
        {{ csrf_field() }}
        <div class="form-group row">
            <label class="col-sm-12 col-md-2 col-form-label">No Inventory</label>
            <div class="col-sm-12 col-md-10">
                <input class="form-control" type="text" name="no_inv" value="{{ $inventory->no_inv }}">
            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-12 col-md-2 col-form-label">Nama Barang</label>
            <div class="col-sm-12 col-md-10">
                <input class="form-control" type="text" name="nama_barang" value="{{ $inventory->nama_barang }}">
            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-12 col-md-2 col-form-label">Unit</label>
            <div class="col-sm-12 col-md-10">
                <input class="form-control" type="text" name="unit" value="{{ $inventory->unit }}">
            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-12 col-md-2 col-form-label">Junmlah Unit</label>
            <div class="col-sm-12 col-md-10">
                <input class="form-control" type="text" name="jumlah" value="{{ $inventory->jumlah_unit }}">
            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-12 col-md-2 col-form-label">Keterangan</label>
            <div class="col-sm-12 col-md-10">
                <input class="form-control" type="text" name="keterangan" value="{{ $inventory->keterangan }}">
            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-12 col-md-2 col-form-label">Gambar</label>
            <div class="col-sm-12 col-md-10">
                <input class="form-control" type="text" name="gambar" value="{{ $inventory->gambar }}">
            </div>
        </div>
        <!-- <div class="form-group row">
                            <label class="col-sm-12 col-md-2 col-form-label">Gambar</label>
                            <div class="col-sm-12 col-md-10">
                                <div>
                                    <input type="file" class="" name="gambar">
                                    <label class="custom-file-label">Choose file</label>
                                </div>
                            </div>
                        </div> -->
        <div class="form-group row">
            <label class="col-sm-12 col-md-2 col-form-label">Pemakaian</label>
            <div class="col-sm-12 col-md-10">
                <input class="form-control" type="text" name="pemakaian" value="{{ $inventory->pemakaian }}">
            </div>
        </div>
        <button type="submit" class="btn btn-primary btn-lg btn-block">Submit</button>
    </form>
</div>
<!-- Default Basic Forms End -->
@endsection
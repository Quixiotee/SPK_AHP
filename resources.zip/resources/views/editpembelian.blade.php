@extends('layout')
@section('pembelian','active')
@section('content')
<!-- Default Basic Forms Start -->
<div class="pd-20 card-box mb-30">
    <div class="clearfix">
        <div class="pull-left">
            <h4 class="text-blue h4">Form Pembelian</h4>
            <p class="mb-30">Tambahkan data Pembelian </p>
        </div>
    </div>
    <form action="/form_pembelian/update/{{$pembelian->id_pembelian}}" method="post" enctype="multipart/form-data">
        {{ csrf_field() }}
        <div class="form-group row">
            <label class="col-sm-12 col-md-2 col-form-label">Id Pembelian</label>
            <div class="col-sm-12 col-md-10">
                <input class="form-control" type="text" name="id_pembelian" value="{{$pembelian->id_pembelian}}" readonly>
            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-12 col-md-2 col-form-label">No Supplier</label>
            <div class="col-sm-12 col-md-10">
                <input class="form-control" type="text" name="no_supplier" value="{{$pembelian->no_supplier}}" readonly>
            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-12 col-md-2 col-form-label">Id_pegawai</label>
            <div class="col-sm-12 col-md-10">
                <input class="form-control" type="text" name="id_pegawai" value="{{$pembelian->id_pegawai}}" readonly>
            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-12 col-md-2 col-form-label">Tanggal Pembelian</label>
            <div class="col-sm-12 col-md-10">
                <input class="form-control" type="date" name="tanggal_pembelian" value="{{$pembelian->tanggal_pembelian}}">
            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-12 col-md-2 col-form-label">Total Harga</label>
            <div class="col-sm-12 col-md-10">
                <input class="form-control" type="text" name="total" value="{{$pembelian->total_harga}}">
            </div>
        </div>
        <button type="submit" class="btn btn-primary btn-lg btn-block">Submit</button>
    </form>
</div>
<!-- Default Basic Forms End -->
@endsection
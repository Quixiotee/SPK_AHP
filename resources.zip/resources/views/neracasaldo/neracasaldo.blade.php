@extends('layout')
@section('content')

<div class="card-box mb-30">
    <div class="pd-20">
        <h4 class="text-blue h4">
            <center>Neraca Saldo</center>
        </h4>
        <p>
            <center>Periode : {{$tgl_awal}} - {{$tgl_akhir}}</center>
        </p>
    </div>

    <div class="pb-20 table-responsive">
        <table class="data-table-export table">
            <thead>
                <tr>
                    <th scope="col" class="sort" data-sort="no">No.</th>
                    <th scope="col" class="sort" data-sort="nama">No. Ref</th>
                    <th scope="col" class="sort" data-sort="nama">Nama Ref</th>
                    <th scope="col" class="sort" data-sort="nama">Debet</th>
                    <th scope="col" class="sort" data-sort="nama">Kredit</th>

                </tr>
            </thead>
            <tbody class="list">
                @php
                $debet = 0;
                $kredit = 0;
                @endphp
                @foreach($data as $index=>$sb)
                <tr>
                    <td>{{ $index+1 }}</td>
                    <td> {{ $sb->ref }}</td>
                    <td> {{ $sb->nama }}</td>
                    <td>@currency($sb -> debet)</td>
                    <td>@currency($sb -> kredit)</td>
                </tr>

                <input type="hidden" value="{{ $debet += $sb->debet}}">
                <input type="hidden" value="{{ $kredit += $sb->kredit}}">
                @endforeach
                <tr>
                    <td colspan="3"><i><b>
                                Jumlah Total
                            </b></i></td>
                    <td><i><b>@currency($debet)</b></i></td>
                    <td><i><b>@currency($kredit)</b></i></td>
                </tr>

                <tr>
                    <td colspan="7">
                        @if($debet== $kredit)
                        <center>
                            <h1 style="color: dark;"><i>Balance</i></h1>
                        </center>
                        @else
                        <center>
                            <h1 style="color: dark;"><i>Tidak Balance</i></h1>
                        </center>
                        @endif
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</div>
</div>
</div>
</div>
</div>

@endsection
@extends('layout')
@section('administrasi','active')
@section('content')
<!-- Default Basic Forms Start -->
<div class="pd-20 card-box mb-30">
    <div class="clearfix">
        <div class="pull-left">
            <h4 class="text-blue h4">Dokumen Administrasi</h4>
            <p class="mb-30">Tambahkan Data Dokumen Administrasi </p>
        </div>
    </div>
    <form action="/administrasi" method="post" enctype="multipart/form-data">
        {{ csrf_field() }}
        <div class="form-group row">
            <label class="col-sm-12 col-md-2 col-form-label">Id Peserta</label>
            <div class="col-sm-12 col-md-10">
                <select class="form-control js-example-basic-single" id="id_peserta" name="id_peserta">
                    @foreach($peserta as $row)
                    <option value="{{$row->id_peserta}}">{{$row->id_peserta}}</option>
                    @endforeach
                </select>
            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-12 col-md-2 col-form-label">Nama Peserta</label>
            <div class="col-sm-12 col-md-10">
                <input class="form-control" type="text" name="nama_peserta" id="nama_peserta" readonly>
            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-12 col-md-2 col-form-label">Kode Diklat</label>
            <div class="col-sm-12 col-md-10">
                <select class="form-control" id="kode_diklat" name="kode_diklat">
                    @foreach($diklat as $row)
                    <option value="{{$row->kode_diklat}}">{{$row->kode_diklat}} - {{$row->nama_diklat}}</option>
                    @endforeach
                </select>
            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-12 col-md-2 col-form-label">Kode Kelas</label>
            <div class="col-sm-12 col-md-10">
                <select class="form-control" id="kode_kelas" name="kode_kelas">
                    @foreach($kelas as $row)
                    <option value="{{$row->id_kelas}}">{{$row->id_kelas}} - {{$row->nama_kelas}}</option>
                    @endforeach
                </select>
            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-12 col-md-2 col-form-label">Id Persyaratan</label>
            <div class="col-sm-12 col-md-10">
                <select class="form-control" id="id_persyaratan" name="id_persyaratan">
                    @foreach($persyaratan as $row => $key)
                    <option value="{{$key->id_persyaratan}}">{{$key->id_persyaratan}} - {{$key->nama_persyaratan}}</option>
                    @endforeach
                </select>
            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-12 col-md-2 col-form-label">Nama File</label>
            <div class="col-sm-12 col-md-10">
                <input class="form-control" type="file" name="nama_file">
            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-12 col-md-2 col-form-label">Keterangan</label>
            <div class="col-sm-12 col-md-10">
                <input class="form-control" type="text" name="keterangan">
            </div>
        </div>
</div>
<button type="submit" class="btn btn-primary btn-lg btn-block">Submit</button>
</form>
</div>
<!-- Default Basic Forms End -->
@endsection
@push('script')
<script>
    $(document).ready(function() {

        $('#id_peserta').on('change', function() {

            let id = $(this).val();

            $.ajax({

                url: '/administrasi/admPeserta/' + id,
                method: 'GET',
                success: function(data) {
                    $("#nama_peserta").val(data);
                }
            });
        });
    });
</script>
@endpush
@extends('layout')
@section('administrasi','active')
@section('content')
<!-- Datatable start -->
<div class="card-box mb-30">
	<div class="pd-20">
		<h4 class="text-blue h4">Administrasi Peserta</h4>
		<a class="btn btn-dark" href="administrasi/create">Create File </a>
	</div>
	<div class="pb-20">
		<table class="data-table-export table">
			<thead>
				<tr>
					<th>Id Persyaratan Diklat</th>
					<th class="datatable-nosort">Id Peserta</th>
					<th class="datatable-nosort">Nama Peserta</th>
					<th class="datatable-nosort">Nama Diklat</th>
					<th class="datatable-nosort">Nama Persyaratan</th>
					<th class="datatable-nosort">Nama File</th>
					<th class="datatable-nosort">Keterangan</th>
					<th class="datatable-nosort">Update By</th>
					<th class="datatable-nosort">Action</th>
				</tr>
			</thead>
			<tbody>
				@foreach($administrasi_peserta as $row)
				<tr>
					<td>{{ $row->id_persyaratan_diklat}}</td>
					<td>{{ $row->id_peserta}}</td>
					<td>{{ $row->nama_peserta}}</td>
					<td>{{ $row->nama_diklat}}</td>
					<td>{{ $row->nama_persyaratan}}</td>
					<td> <a href="file_persyaratan/{{$row->nama_file}}" target="_blank">{{ $row->nama_file}} </a></td>
					<td>{{ $row->keterangan}}</td>
					<td>{{ $row->update_by}}</td>
					<td>
						<div class="dropdown">
							<a class="btn btn-link font-24 p-0 line-height-1 no-arrow dropdown-toggle" href="#" role="button" data-toggle="dropdown">
								<i class="dw dw-more"></i>
							</a>
							<div class="dropdown-menu dropdown-menu-right dropdown-menu-icon-list">
							<a class="dropdown-item" href="/administrasi/{{$row->id_persyaratan_diklat}}/edit"><i class="dw dw-edit2"></i> Edit</a>
								<form action="administrasi/{{$row->id_persyaratan_diklat}}" method="post">
									@csrf
									@method('delete')
									<button class="dropdown-item"><i class="dw dw-delete-3"></i> Delete</button>
								</form>
							</div>
						</div>
					</td>
				</tr>
				@endforeach
			</tbody>
		</table>
	</div>
</div>
<!-- Datatable End -->
@endsection
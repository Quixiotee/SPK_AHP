@extends('layout')
@section('administrasi','active')
@section('content')
<!-- Default Basic Forms Start -->
<div class="pd-20 card-box mb-30">
    <div class="clearfix">
        <div class="pull-left">
            <h4 class="text-blue h4">Dokumen Administrasi</h4>
            <p class="mb-30">Tambahkan Data Dokumen Administrasi </p>
        </div>
    </div>
    <form action="/administrasi/{{$persyaratan_diklat -> id_persyaratan_diklat}}" method="post" enctype="multipart/form-data">
        {{ csrf_field() }}
        @method('put')
        <div class="form-group row">
            <label class="col-sm-12 col-md-2 col-form-label">Id Peserta</label>
            <div class="col-sm-12 col-md-10">
            <input class="form-control" type="text" name="id_peserta" id="id_peserta" value="{{$persyaratan_diklat -> id_peserta}}" readonly>
            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-12 col-md-2 col-form-label">Nama Peserta</label>
            <div class="col-sm-12 col-md-10">
                <input class="form-control" type="text" name="nama_peserta" id="nama_peserta" value="{{$persyaratan_diklat -> nama_peserta}}" readonly>
            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-12 col-md-2 col-form-label">Kode Diklat</label>
            <div class="col-sm-12 col-md-10">
                <select class="form-control" id="exampleFormControlSelect1" name="kode_diklat">
                    @foreach($diklat as $row)
                    <option value="{{$row->kode_diklat}}" @if($row->kode_diklat == $persyaratan_diklat->kode_diklat) selected @endif>{{$row->kode_diklat}}</option>
                    @endforeach
                </select>
            </div>
        </div>
        
        <div class="form-group row">
            <label class="col-sm-12 col-md-2 col-form-label">Id Persyaratan</label>
            <div class="col-sm-12 col-md-10">
                <select class="form-control" id="exampleFormControlSelect1" name="id_persyaratan">
                    @foreach($persyaratan as $row)
                    <option value="{{$row->id_persyaratan}}">{{$row->id_persyaratan}} - {{$row->nama_persyaratan}}</option>
                    @endforeach
                </select>
            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-12 col-md-2 col-form-label">Nama File</label>
            <div class="col-sm-12 col-md-10">
                <input class="form-control" type="file" name="nama_file" value="{{$persyaratan_diklat -> nama_file}}">
            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-12 col-md-2 col-form-label">Keterangan</label>
            <div class="col-sm-12 col-md-10">
                <input class="form-control" type="text" name="keterangan" value="{{$persyaratan_diklat -> keterangan}}">
            </div>
        </div>
</div>
<button type="submit" class="btn btn-primary btn-lg btn-block">Submit</button>
</form>
</div>
<!-- Default Basic Forms End -->
@endsection
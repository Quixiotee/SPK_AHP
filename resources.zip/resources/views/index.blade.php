<html>

<head>
	<!-- Basic Page Info -->
	<meta charset="utf-8">
	<title>Perwita Maritim Pershada</title>

	<!-- Site favicon -->
	<link rel="apple-touch-icon" sizes="180x180" href="{{asset('assets/vendors/images/apple-touch-icon.png')}}">
	<link rel="icon" type="image/png" sizes="32x32" href="{{asset('assets/vendors/images/favicon-32x32.png')}}">
	<link rel="icon" type="image/png" sizes="16x16" href="{{asset('assets/vendors/images/favicon-16x16.png')}}">

	<!-- Mobile Specific Metas -->
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

	<!-- Google Font -->
	<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
	<!-- CSS -->
	<link rel="stylesheet" type="text/css" href="{{asset('assets/vendors/styles/core.css')}}">
	<link rel="stylesheet" type="text/css" href="{{asset('assets/vendors/styles/icon-font.min.css')}}">
	<link rel="stylesheet" type="text/css" href="{{asset('assets/src/plugins/datatables/css/dataTables.bootstrap4.min.css')}}">
	<link rel="stylesheet" type="text/css" href="{{asset('assets/src/plugins/datatables/css/responsive.bootstrap4.min.css')}}">
	<link rel="stylesheet" type="text/css" href="{{asset('assets/vendors/styles/style.css')}}">

	<!-- Global site tag (gtag.js) - Google Analytics -->
	<script async src="https://www.googletagmanager.com/gtag/js?id=UA-119386393-1"></script>
	<script>
		window.dataLayer = window.dataLayer || [];

		function gtag() {
			dataLayer.push(arguments);
		}
		gtag('js', new Date());

		gtag('config', 'UA-119386393-1');
	</script>
</head>

<body>
	<div class="pre-loader">
		<div class="pre-loader-box">
			<div class="loader-logo"><img src="{{asset('assets/vendors/images/logo.png')}}" alt=""></div>
			<div class='loader-progress' id="progress_div">
				<div class='bar' id='bar1'></div>
			</div>
			<div class='percent' id='percent1'>0%</div>
			<div class="loading-text">
				Loading...
			</div>
		</div>
	</div>

	<div class="header">
		<div class="header-left">
			<div class="menu-icon dw dw-menu"></div>
		</div>

		<div class="header-right">
			<div class="dashboard-setting user-notification">
				<div class="dropdown">
					<a class="dropdown-toggle no-arrow" href="#" role="button" data-toggle="dropdown">
						<i class="dw dw-settings2"></i>
					</a>
					<div class="user-info-dropdown">
						<div>
							<div class="dropdown-menu dropdown-menu-right dropdown-menu-icon-list" style="width:100px; padding-top:10px;">
								<a class="dropdown-item" href="/logout"><i class="dw dw-logout"></i> Log Out</a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<div class="left-side-bar">
		<div class="brand-logo">
			<a href="index">
				<img src="{{asset('assets/vendors/images/logo-perwita.png')}}" alt="" style="width: 70px;" class="light-logo"> Perwita
			</a>
			<div class="close-sidebar" data-toggle="left-sidebar-close">
				<i class="ion-close-round"></i>
			</div>
		</div>
		<div class="menu-block customscroll">
			<div class="sidebar-menu">
				<ul id="accordion-menu">
					<li class="dropdown">
						<a href="{{route('index.index')}}" class="dropdown-toggle">
							<span class="micon dw dw-house-1"></span><span class="mtext">Home</span>
						</a>
					</li>
					<li class="dropdown">
						<a href="javascript:;" class="dropdown-toggle">
							<span class="micon dw dw-library"></span><span class="mtext">Data Master</span>
						</a>
						<ul class="submenu">
							<li><a href="{{route('peserta.index')}}">Data Peserta</a></li>
							<li><a href="{{route('pegawai.index')}}">Data Pegawai</a></li>
							<li><a href="{{route('instruktur.index')}}">Data Instruktur</a></li>
							<li><a href="{{route('diklat.index')}}">Data Diklat</a></li>
							<li><a href="{{route('user.index')}}">Data User</a></li>
							<li><a href="{{route('masterkelas.index')}}">Data Kelas</a></li>
						</ul>
					</li>
					<li class="dropdown">
						<a href="javascript:;" class="dropdown-toggle">
							<span class="micon dw dw-clipboard"></span><span class="mtext">Administrasi Peserta</span>
						</a>
						<ul class="submenu">
							<li><a class="breadcrumb-item @yield('administrasi')" href="{{route('administrasi.index')}}">Data Administrasi</a></li>
							<li><a class="breadcrumb-item @yield('pembayaran')" href="{{route('pembayaran.index')}}">Pembayaran</a></li>
							<li><a class="breadcrumb-item @yield('kelas')" href="{{route('kelas.index')}}">Kelas Peserta</a></li>
							<li><a class="breadcrumb-item @yield('jadwal')" href="{{route('jadwal.index')}}">Jadwal</a></li>
						</ul>
					</li>
					<li class="dropdown">
						<a href="javascript:;" class="dropdown-toggle">
							<span class="micon dw dw-books"></span><span class="mtext">Pembelian </span>
						</a>
						<ul class="submenu">
							<li><a class="breadcrumb-item @yield('form_pembelian')" href="{{route('form_pembelian.index')}}">Form Pembelian</a></li>
							<li><a class="breadcrumb-item @yield('form_inventory')" href="{{route('form_inventory.index')}}">Form Inventory</a></li>
							<li><a class="breadcrumb-item @yield('form_supplier')" href="{{route('form_supplier.index')}}">Form Supplier</a></li>
							<li><a class="breadcrumb-item @yield('pembelian')" href="{{route('pembelian.index')}}">Pembelian</a></li>
							<li><a class="breadcrumb-item @yield('inventory')" href="{{route('inventory.index')}}">Inventory</a></li>
							<li><a class="breadcrumb-item @yield('supplier')" href="{{route('supplier.index')}}">Supplier</a></li>
						</ul>
					</li>
					<li class="dropdown">
						<a href="javascript:;" class="dropdown-toggle">
							<span class="micon dw dw-book"></span><span class="mtext">Data Tabel</span>
						</a>
						<ul class="submenu">
							<li><a class="breadcrumb-item @yield('akun')" href="{{route('akun.index')}}">Akun</a></li>
							<li><a class="breadcrumb-item @yield('jurnalumum')" href="{{route('jurnalumum.index')}}">Jurnal Umum</a></li>
							<li><a class="breadcrumb-item @yield('jurnalpenyesuaian')" href="{{route('jurnalpenyesuaian.index')}}">Jurnal Penyesuaian</a></li>
							<li><a class="breadcrumb-item @yield('bukubesar')" href="{{route('bukubesar.index')}}">Buku Besar</a></li>
							<li><a class="breadcrumb-item @yield('neracasaldo')" href="{{route('neracasaldo.index')}}">Neraca Saldo</a></li>
							<li><a class="breadcrumb-item @yield('neracalajur')" href="{{route('neracalajur.index')}}">Neraca Lajur</a></li>
						</ul>
					</li>
					<li class="dropdown">
						<a href="javascript:;" class="dropdown-toggle">
							<span class="micon dw dw-sheet"></span><span class="mtext">Laporan</span>
						</a>
						<ul class="submenu">
							<li><a class="breadcrumb-item" href="{{route('labarugi.index')}}">Laporan Laba Rugi</a></li>
							<li><a class="breadcrumb-item" href="{{route('perubahanmodal.index')}}">Laporan Perubahan Modal</a></li>
						</ul>
					</li>
				</ul>
			</div>
		</div>
	</div>
	<div class="mobile-menu-overlay"></div>

	<div class="main-container">
		<div class="pd-ltr-20">
			<div class="card-box pd-20 height-25-p mb-30">
				<div class="row align-items-center">
					<div class="col-md-4">
						<img src="{{asset('assets/vendors/images/banner-img.png')}}" alt="">
					</div>
					<div class="col-md-8">
						<h4 class="font-20 weight-500 mb-10 text-capitalize">
							Welcome back <div class="weight-600 font-30 text-blue">Administrator!</div>
						</h4>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-xl-4 mb-30">
					<div class="card-box height-100-p widget-style1">
						<div class="d-flex flex-wrap align-items-center">
							<div class="progress-data">
								<div id="chart"></div>
							</div>
							<div class="widget-data">
								<div class="h4 mb-0">Pembayaran Lunas</div>
								<div class="weight-600 font-14">Bulan ini</div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-xl-4 mb-30">
					<div class="card-box height-100-p widget-style1">
						<div class="d-flex flex-wrap align-items-center">
							<div class="progress-data">
								<div id="chart2"></div>
							</div>
							<div class="widget-data">
								<div class="h4 mb-0">Pembayaran Angsuran</div>
								<div class="weight-600 font-14">Bulan ini</div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-xl-4 mb-30">
					<div class="card-box height-100-p widget-style1">
						<div class="d-flex flex-wrap align-items-center">
							<div class="progress-data">
								<div id="chart3"></div>
							</div>
							<div class="widget-data">
								<div class="h4 mb-0">Pembayaran Belum Mengangsur</div>
								<div class="weight-600 font-14">Bulan ini</div>
							</div>
						</div>
					</div>
				</div>
				<!-- <div class="col-xl-3 mb-30">
					<div class="card-box height-100-p widget-style1">
						<div class="d-flex flex-wrap align-items-center">
							<div class="progress-data">
								<div id="chart4"></div>
							</div>
							<div class="widget-data">
								<div class="h4 mb-0">$6060</div>
								<div class="weight-600 font-14">Worth</div>
							</div>
						</div>
					</div>
				</div> -->
			</div>
			<div class="row">
				<div class="col-xl-6 mb-30">
					<div class="card-box height-100-p pd-20">
						<h2 class="h4 mb-20">Grafik Peserta</h2>
						<div id="chart5"></div>
					</div>
				</div>
				<div class="col-xl-6 mb-30">
					<div class="card-box height-100-p pd-20">
						<h2 class="h4 mb-20">Grafik Laba Rugi</h2>
						<div id="chart6"></div>
					</div>
				</div>
			</div>
			<div class="footer-wrap pd-20 mb-20 card-box">
				©ANFTeam 2021<a href="" target="_blank"></a>
			</div>
		</div>
	</div>
	<!-- js -->
	<script src="{{asset('assets/vendors/scripts/core.js')}}"></script>
	<script src="{{asset('assets/vendors/scripts/script.min.js')}}"></script>
	<script src="{{asset('assets/vendors/scripts/process.js')}}"></script>
	<script src="{{asset('assets/vendors/scripts/layout-settings.js')}}"></script>
	<script src="{{asset('assets/src/plugins/apexcharts/apexcharts.min.js')}}"></script>
	<script src="{{asset('assets/src/plugins/datatables/js/jquery.dataTables.min.js')}}"></script>
	<script src="{{asset('assets/src/plugins/datatables/js/dataTables.bootstrap4.min.js')}}"></script>
	<script src="{{asset('assets/src/plugins/datatables/js/dataTables.responsive.min.js')}}"></script>
	<script src="{{asset('assets/src/plugins/datatables/js/responsive.bootstrap4.min.js')}}"></script>
	<!-- <script src="{{asset('assets/vendors/scripts/dashboard.js')}}"></script> -->
	<script>
		$('document').ready(function() {
			var options;
			$.ajax({
				url:"/chart2",
				method:'get',
				async: false,
				success:function(data){
				
			options = {
				series: [data],
				grid: {
					padding: {
						top: 0,
						right: 0,
						bottom: 0,
						left: 0
					},
				},
				chart: {
					height: 100,
					width: 70,
					type: 'radialBar',
				},
				plotOptions: {
					radialBar: {
						hollow: {
							size: '50%',
						},
						dataLabels: {
							name: {
								show: false,
								color: '#fff'
							},
							value: {
								show: true,
								color: '#333',
								offsetY: 5,
								fontSize: '15px'
							}
						}
					}
				},
				colors: ['#ecf0f4'],
				fill: {
					type: 'gradient',
					gradient: {
						shade: 'dark',
						type: 'diagonal1',
						shadeIntensity: 0.8,
						gradientToColors: ['#1b00ff'],
						inverseColors: false,
						opacityFrom: [1, 0.2],
						opacityTo: 1,
						stops: [0, 100],
					}
				},
				states: {
					normal: {
						filter: {
							type: 'none',
							value: 0,
						}
					},
					hover: {
						filter: {
							type: 'none',
							value: 0,
						}
					},
					active: {
						filter: {
							type: 'none',
							value: 0,
						}
					},
				}
			}
		}		
	});
			
			var options2;
			$.ajax({
				url:"/chart3",
				method:'get',
				async: false,
				success:function(data){
			
			options2 = {
				series: [data],
				grid: {
					padding: {
						top: 0,
						right: 0,
						bottom: 0,
						left: 0
					},
				},
				chart: {
					height: 100,
					width: 70,
					type: 'radialBar',
				},
				plotOptions: {
					radialBar: {
						hollow: {
							size: '50%',
						},
						dataLabels: {
							name: {
								show: false,
								color: '#fff'
							},
							value: {
								show: true,
								color: '#333',
								offsetY: 5,
								fontSize: '15px'
							}
						}
					}
				},
				colors: ['#ecf0f4'],
				fill: {
					type: 'gradient',
					gradient: {
						shade: 'dark',
						type: 'diagonal1',
						shadeIntensity: 1,
						gradientToColors: ['#009688'],
						inverseColors: false,
						opacityFrom: [1, 0.2],
						opacityTo: 1,
						stops: [0, 100],
					}
				},
				states: {
					normal: {
						filter: {
							type: 'none',
							value: 0,
						}
					},
					hover: {
						filter: {
							type: 'none',
							value: 0,
						}
					},
					active: {
						filter: {
							type: 'none',
							value: 0,
						}
					},
				}
			};
				}
			})
			

			var options3;
			$.ajax({
				url:"/chart4",
				method:'get',
				async: false,
				success:function(data){
					options3 = {
				series: [data],
				grid: {
					padding: {
						top: 0,
						right: 0,
						bottom: 0,
						left: 0
					},
				},
				chart: {
					height: 100,
					width: 70,
					type: 'radialBar',
				},
				plotOptions: {
					radialBar: {
						hollow: {
							size: '50%',
						},
						dataLabels: {
							name: {
								show: false,
								color: '#fff'
							},
							value: {
								show: true,
								color: '#333',
								offsetY: 5,
								fontSize: '15px'
							}
						}
					}
				},
				colors: ['#ecf0f4'],
				fill: {
					type: 'gradient',
					gradient: {
						shade: 'dark',
						type: 'diagonal1',
						shadeIntensity: 0.8,
						gradientToColors: ['#f56767'],
						inverseColors: false,
						opacityFrom: [1, 0.2],
						opacityTo: 1,
						stops: [0, 100],
					}
				},
				states: {
					normal: {
						filter: {
							type: 'none',
							value: 0,
						}
					},
					hover: {
						filter: {
							type: 'none',
							value: 0,
						}
					},
					active: {
						filter: {
							type: 'none',
							value: 0,
						}
					},
				}
			};
				}
			})
			

			var options4 = {
				series: [85],
				grid: {
					padding: {
						top: 0,
						right: 0,
						bottom: 0,
						left: 0
					},
				},
				chart: {
					height: 100,
					width: 70,
					type: 'radialBar',
				},
				plotOptions: {
					radialBar: {
						hollow: {
							size: '50%',
						},
						dataLabels: {
							name: {
								show: false,
								color: '#fff'
							},
							value: {
								show: true,
								color: '#333',
								offsetY: 5,
								fontSize: '15px'
							}
						}
					}
				},
				colors: ['#ecf0f4'],
				fill: {
					type: 'gradient',
					gradient: {
						shade: 'dark',
						type: 'diagonal1',
						shadeIntensity: 0.8,
						gradientToColors: ['#2979ff'],
						inverseColors: false,
						opacityFrom: [1, 0.5],
						opacityTo: 1,
						stops: [0, 100],
					}
				},
				states: {
					normal: {
						filter: {
							type: 'none',
							value: 0,
						}
					},
					hover: {
						filter: {
							type: 'none',
							value: 0,
						}
					},
					active: {
						filter: {
							type: 'none',
							value: 0,
						}
					},
				}
			};

			var options5;
			$.ajax({
				url: '/chart',
				method: 'get',
				async: false,
				success: function(data) {
					var total = []
					var bulan = ["January", "February", "March", "April", "May", "June",
						"July", "August", "September", "October", "November", "December"
					];
					var databulan = []
					for (i = 0; i <= bulan.length; i++) {
						data.forEach(element => {

							if (i == element['Bulan'] - 1) {
								total.push(element['total'])
								databulan.push(bulan[i])
							}
						})
					}
					options5 = {
						series: [{
							name: "Peserta",
							data: total
						}],
						chart: {
							height: 350,
							type: 'line',
							zoom: {
								enabled: false
							}
						},
						dataLabels: {
							enabled: false
						},
						stroke: {
							curve: 'straight'
						},
						title: {
							text: 'Grafik Peserta Per Bulan',
							align: 'left'
						},
						grid: {
							row: {
								colors: ['#f3f3f3', 'transparent'], // takes an array which will be repeated on columns
								opacity: 0.5
							},
						},
						xaxis: {
							categories: databulan
						}
					};
				}
			})



			var options6 = {
				series: [{
						name: "",
						data: [28, 29, 33, 36, 32, 32, 33]
					},
					{
						name: "",
						data: [12, 11, 14, 18, 17, 13, 13]
					}
				],
				chart: {
					height: 350,
					type: 'line',
					dropShadow: {
						enabled: true,
						color: '#000',
						top: 18,
						left: 7,
						blur: 10,
						opacity: 0.2
					},
					toolbar: {
						show: false
					}
				},
				colors: ['#77B6EA', '#545454'],
				dataLabels: {
					enabled: true,
				},
				stroke: {
					curve: 'smooth'
				},
				title: {
					text: 'Grafik Laba Rugi Per Bulan',
					align: 'left'
				},
				grid: {
					borderColor: '#e7e7e7',
					row: {
						colors: ['#f3f3f3', 'transparent'], // takes an array which will be repeated on columns
						opacity: 0.5
					},
				},
				markers: {
					size: 1
				},
				xaxis: {
					categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul'],
					title: {
						text: 'Month'
					}
				},
				yaxis: {
					title: {
						text: ''
					},
					min: 5,
					max: 40
				},
				legend: {
					position: 'top',
					horizontalAlign: 'right',
					floating: true,
					offsetY: -25,
					offsetX: -5
				}
			};

			var chart = new ApexCharts(document.querySelector("#chart"), options);
			chart.render();

			var chart2 = new ApexCharts(document.querySelector("#chart2"), options2);
			chart2.render();

			var chart3 = new ApexCharts(document.querySelector("#chart3"), options3);
			chart3.render();

			var chart4 = new ApexCharts(document.querySelector("#chart4"), options4);
			chart4.render();

			var chart5 = new ApexCharts(document.querySelector("#chart5"), options5);
			chart5.render();

			var chart6 = new ApexCharts(document.querySelector("#chart6"), options6);
			chart6.render();


			// datatable init

			$('.data-table').DataTable({
				scrollCollapse: true,
				autoWidth: true,
				responsive: true,
				searching: false,
				bLengthChange: false,
				bPaginate: false,
				bInfo: false,
				columnDefs: [{
					targets: "datatable-nosort",
					orderable: false,
				}],
				"lengthMenu": [
					[10, 25, 50, -1],
					[10, 25, 50, "All"]
				],
				"language": {
					"info": "_START_-_END_ of _TOTAL_ entries",
					searchPlaceholder: "Search",
					paginate: {
						next: '<i class="ion-chevron-right"></i>',
						previous: '<i class="ion-chevron-left"></i>'
					}
				},
			});
		});
	</script>
</body>

</html>
@extends('layout')
@section('diklat','active')
@section('content')
<!-- Default Basic Forms Start -->
<div class="pd-20 card-box mb-30">
    <div class="clearfix">
        <div class="pull-left">
            <h4 class="text-blue h4">Data Diklat</h4>
            <p class="mb-30">Edit Data Diklat</p>
        </div>
    </div>
    <form action="/diklat/{{$diklat -> kode_diklat}}" method="post" enctype="multipart/form-data">
        {{ csrf_field() }}
        @method('put')
        <div class="form-group row">
            <label class="col-sm-12 col-md-2 col-form-label">Id Diklat</label>
            <div class="col-sm-12 col-md-10">
                <input class="form-control" type="text" name="kode_diklat" value="{{$diklat -> kode_diklat}}" readonly>
            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-12 col-md-2 col-form-label">Nama Diklat</label>
            <div class="col-sm-12 col-md-10">
                <input class="form-control" type="text" name="nama_diklat" value="{{$diklat -> nama_diklat}}">
            </div>
        </div>
        <div class=" form-group row">
            <label class="col-sm-12 col-md-2 col-form-label">Durasi</label>
            <div class="col-sm-12 col-md-10">
                <input class="form-control" type="text" name="durasi" value="{{$diklat -> durasi}}">
            </div>
        </div>
        <div class=" form-group row">
            <label class="col-sm-12 col-md-2 col-form-label">Harga</label>
            <div class="col-sm-12 col-md-10">
                <input class="form-control" type="number" name="harga" value="{{$diklat -> harga}}">
            </div>
        </div>
        <button type=" submit" class="btn btn-primary btn-lg btn-block">Submit</button>
    </form>
</div>
<!-- Default Basic Forms End -->
@endsection
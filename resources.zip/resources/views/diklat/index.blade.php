@extends('layout')
@section('diklat','active')
@section('content')
<!-- Datatable start -->
<div class="card-box mb-30">
	<div class="pd-20">
		<h4 class="text-blue h4">Data Diklat</h4>
		<a class="btn btn-dark" href="diklat/create">Create File </a>
	</div>
	<div class="pb-20">
		<table class="data-table-export table">
			<thead>
				<tr>
					<th>Id Diklat</th>
					<th class="datatable-nosort">Nama Diklat</th>
					<th class="datatable-nosort">Durasi</th>
					<th class="datatable-nosort">Harga</th>
					<th class="datatable-nosort">Log Activity</th>
					<th class="datatable-nosort">Action</th>
				</tr>
			</thead>
			<tbody>
				@foreach($diklat as $row)
				<tr>
					<td>{{ $row->kode_diklat}}</td>
					<td>{{ $row->nama_diklat}}</td>
					<td>{{ $row->durasi}}</td>
					<td>{{ $row->harga}}</td>
					<td>{{ $row->update_by}}</td>
					<td>
						<div class="dropdown">
							<a class="btn btn-link font-24 p-0 line-height-1 no-arrow dropdown-toggle" href="#" role="button" data-toggle="dropdown">
								<i class="dw dw-more"></i>
							</a>
							<div class="dropdown-menu dropdown-menu-right dropdown-menu-icon-list">
                            <a class="dropdown-item" href="/diklat/{{$row->kode_diklat}}/edit"><i class="dw dw-edit2"></i> Edit</a>
							</div>
						</div>
					</td>
				</tr>
				@endforeach
			</tbody>
		</table>
	</div>
</div>
<!-- Datatable End -->
@endsection
<div class="sidebar-menu">
	<ul id="accordion-menu">
		<li class="dropdown">
			<a href="{{route('index.index')}}" class="dropdown-toggle">
				<span class="micon dw dw-house-1"></span><span class="mtext">Home</span>
			</a>
		</li>
		<li class="dropdown">
			<a href="javascript:;" class="dropdown-toggle">
				<span class="micon dw dw-library"></span><span class="mtext">Data Master</span>
			</a>
			<ul class="submenu">
				<li><a class="breadcrumb-item @yield('peserta')" href="{{route('peserta.index')}}">Data Peserta</a></li>
				<li><a class="breadcrumb-item @yield('pegawai')" href="{{route('pegawai.index')}}">Data Pegawai</a></li>
				<li><a class="breadcrumb-item @yield('instruktur')" href="{{route('instruktur.index')}}">Data Instruktur</a></li>
				<li><a class="breadcrumb-item @yield('diklat')" href="{{route('diklat.index')}}">Data Diklat</a></li>
				<li><a class="breadcrumb-item @yield('masterkelas')" href="{{route('masterkelas.index')}}">Data Kelas</a></li>
				<li><a class="breadcrumb-item @yield('user')" href="{{route('user.index')}}">Data User</a></li>
			</ul>
		</li>
		<li class="dropdown">
			<a href="javascript:;" class="dropdown-toggle">
				<span class="micon dw dw-clipboard"></span><span class="mtext">Administrasi Peserta</span>
			</a>
			<ul class="submenu">
				<li><a class="breadcrumb-item @yield('administrasi')" href="{{route('administrasi.index')}}">Data Administrasi</a></li>
				<li><a class="breadcrumb-item @yield('pembayaran')" href="{{route('pembayaran.index')}}">Pembayaran</a></li>
				<li><a class="breadcrumb-item @yield('kelas')" href="{{route('kelas.index')}}">Kelas Peserta</a></li>
				<li><a class="breadcrumb-item @yield('jadwal')" href="{{route('jadwal.index')}}">Jadwal</a></li>
			</ul>
		</li>
		<li class="dropdown">
			<a href="javascript:;" class="dropdown-toggle">
				<span class="micon dw dw-books"></span><span class="mtext">Pembelian </span>
			</a>
			<ul class="submenu">
				<li><a class="breadcrumb-item @yield('form_pembelian')" href="{{route('form_pembelian.index')}}">Form Pembelian</a></li>
				<li><a class="breadcrumb-item @yield('form_inventory')" href="{{route('form_inventory.index')}}">Form Inventory</a></li>
				<li><a class="breadcrumb-item @yield('form_supplier')" href="{{route('form_supplier.index')}}">Form Supplier</a></li>
				<li><a class="breadcrumb-item @yield('pembelian')" href="{{route('pembelian.index')}}">Pembelian</a></li>
				<li><a class="breadcrumb-item @yield('inventory')" href="{{route('inventory.index')}}">Inventory</a></li>
				<li><a class="breadcrumb-item @yield('supplier')" href="{{route('supplier.index')}}">Supplier</a></li>
			</ul>
		</li>
		<li class="dropdown">
			<a href="javascript:;" class="dropdown-toggle">
				<span class="micon dw dw-book"></span><span class="mtext">Data Tabel</span>
			</a>
			<ul class="submenu">
				<li><a class="breadcrumb-item @yield('akun')" href="{{route('akun.index')}}">Akun</a></li>
				<li><a class="breadcrumb-item @yield('jurnalumum')" href="{{route('jurnalumum.index')}}">Jurnal Umum</a></li>
				<li><a class="breadcrumb-item @yield('jurnalpenyesuaian')" href="{{route('jurnalpenyesuaian.index')}}">Jurnal Penyesuaian</a></li>
				<li><a class="breadcrumb-item @yield('bukubesar')" href="{{route('bukubesar.index')}}">Buku Besar</a></li>
				<li><a class="breadcrumb-item @yield('neracasaldo')" href="{{route('neracasaldo.index')}}">Neraca Saldo</a></li>
				<li><a class="breadcrumb-item @yield('neracalajur')" href="{{route('neracalajur.index')}}">Neraca Lajur</a></li>
			</ul>
		</li>
		<li class="dropdown">
			<a href="javascript:;" class="dropdown-toggle">
				<span class="micon dw dw-sheet"></span><span class="mtext">Laporan</span>
			</a>
			<ul class="submenu">
				<li><a class="breadcrumb-item" href="{{route('labarugi.index')}}">Laporan Laba Rugi</a></li>
				<li><a class="breadcrumb-item" href="{{route('perubahanmodal.index')}}">Laporan Perubahan Modal</a></li>
			</ul>
		</li>
	</ul>
</div>
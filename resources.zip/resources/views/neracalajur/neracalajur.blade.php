@extends('layout')
@section('content')


<div class="card-box mb-30">
    <div class="pd-20">
        <h4 class="text-blue h4">
            <center>Neraca Lajur</center>
        </h4>
        <p>
            <center>Periode : {{$tgl_awal}} - {{$tgl_akhir}}</center>
        </p>
    </div>
    <div class="pb-20 table-responsive">
        <table class="data-table-export table">
            <thead>
                <tr>
                    <th scope="col" class="sort" data-sort="no" rowspan="2">Nama Ref</th>
                    <th scope="col" class="sort" data-sort="nama" colspan="2">
                        <center>
                            Neraca Saldo
                        </center>
                    </th>
                    <th scope="col" class="sort" data-sort="nama" colspan="2">
                        <center>
                            AJP
                        </center>
                    </th>
                    <th scope="col" class="sort" data-sort="nama" colspan="2">
                        <center>
                            NSSP
                        </center>
                    </th>
                    <th scope="col" class="sort" data-sort="nama" colspan="2">
                        <center>
                            Laporan Laba Rugi
                        </center>
                    </th>
                    <th scope="col" class="sort" data-sort="nama" colspan="2">
                        <center>
                            Lap. Posisi Keuangan
                        </center>
                    </th>
                </tr>
                <tr>
                    <th scope="col" class="sort" data-sort="nama">Debet</th>
                    <th scope="col" class="sort" data-sort="nama">Kredit</th>
                    <th scope="col" class="sort" data-sort="nama">Debet</th>
                    <th scope="col" class="sort" data-sort="nama">Kredit</th>
                    <th scope="col" class="sort" data-sort="nama">Debet</th>
                    <th scope="col" class="sort" data-sort="nama">Kredit</th>
                    <th scope="col" class="sort" data-sort="nama">Debet</th>
                    <th scope="col" class="sort" data-sort="nama">Kredit</th>
                    <th scope="col" class="sort" data-sort="nama">Debet</th>
                    <th scope="col" class="sort" data-sort="nama">Kredit</th>
                </tr>
            </thead>
            <tbody class="list">
                @php
                $debet_neraca = 0;
                $kredit_neraca = 0;
                $debet_ajp = 0;
                $kredit_ajp = 0;
                $debet_nssp = 0;
                $kredit_nssp = 0;
                $debet_laba = 0;
                $kredit_laba =0;
                $debet_lap = 0;
                $kredit_lap =0;
                $r[] = [];
                @endphp
                @foreach($data as $index=>$sb)
                <tr>
                    <input type="hidden" value="{{ $debet_neraca += $sb->debit}}">
                    <input type="hidden" value="{{ $kredit_neraca += $sb->kredit}}">
                    <input type="hidden" value="{{ $debet_ajp += $sb->debitJP}}">
                    <input type="hidden" value="{{ $kredit_ajp += $sb->kreditJP}}">
                    <td> {{ $sb->nama }}</td>
                    <td>@currency($sb -> debit)</td>
                    <td>@currency($sb -> kredit)</td>
                    <td> @currency($sb -> debitJP)</td>
                    <td>@currency($sb -> kreditJP)</td>
                    @if(($sb -> debit + $sb -> debitJP) - ($sb -> kredit + $sb -> kreditJP) > 0)
                    <td> @currency(($sb -> debit + $sb -> debitJP) - ($sb -> kredit + $sb -> kreditJP))</td>
                    <input type="hidden" value="{{ $debet_nssp += ($sb -> debit + $sb -> debitJP) - ($sb -> kredit + $sb -> kreditJP)}}">
                    @else
                    <td> @currency(0)</td>
                    @endif
                    @if(($sb -> kredit + $sb -> kreditJP) - ($sb -> debit + $sb -> debitJP) > 0)
                    <td>@currency(($sb -> kredit + $sb -> kreditJP) - ($sb -> debit + $sb -> debitJP))</td>
                    <input type="hidden" value="{{ $kredit_nssp += ($sb -> kredit + $sb -> kreditJP) - ($sb -> debit + $sb -> debitJP)}}">
                    @else
                    <td>@currency(0)</td>
                    @endif
                    @if((($sb->ref == '500') || ($sb->ref == '510') || ($sb->ref == '511')|| ($sb->ref == '512') || ($sb->ref == '513')|| ($sb->ref == '514') || ($sb->ref == '515') || ($sb->ref == '516') || ($sb->ref == '517') || ($sb->ref == '518') ) || (($sb->ref == '400') ||($sb->ref == '410') || ($sb->ref == '411')|| ($sb->ref == '412')))
                    @if(($sb -> debit + $sb -> debitJP) - ($sb -> kredit + $sb -> kreditJP) > 0)
                    <td> @currency(($sb -> debit + $sb -> debitJP) - ($sb -> kredit + $sb -> kreditJP))</td>
                    <input type="hidden" value="{{ $debet_laba += ($sb -> debit + $sb -> debitJP) - ($sb -> kredit + $sb -> kreditJP)}}">
                    @else
                    <td> @currency(0)</td>
                    @endif

                    @if(($sb -> kredit + $sb -> kreditJP) - ($sb -> debit + $sb -> debitJP) > 0)
                    <td>@currency(($sb -> kredit + $sb -> kreditJP) - ($sb -> debit + $sb -> debitJP))</td>
                    <input type="hidden" value="{{ $kredit_laba += ($sb -> kredit + $sb -> kreditJP) - ($sb -> debit + $sb -> debitJP)}}">
                    @else
                    <td>@currency(0)</td>
                    @endif
                    @else
                    <td>@currency(0)</td>
                    <td>@currency(0)</td>
                    @endif


                    @if((($sb->ref == '500') || ($sb->ref == '510') || ($sb->ref == '511')|| ($sb->ref == '512') || ($sb->ref == '513')|| ($sb->ref == '514') || ($sb->ref == '515') || ($sb->ref == '516') || ($sb->ref == '517') || ($sb->ref == '518')) || (($sb->ref == '400') || ($sb->ref == '410') || ($sb->ref == '411')|| ($sb->ref == '412')))
                    <td>@currency(0)</td>
                    <td>@currency(0)</td>
                    @else
                    @if(($sb -> debit + $sb -> debitJP) - ($sb -> kredit + $sb -> kreditJP) > 0)
                    <td> @currency(($sb -> debit + $sb -> debitJP) - ($sb -> kredit + $sb -> kreditJP))</td>
                    <input type="hidden" value="{{ $debet_lap += ($sb -> debit + $sb -> debitJP) - ($sb -> kredit + $sb -> kreditJP)}}">
                    @else
                    <td> @currency(0)</td>
                    @endif

                    @if(($sb -> kredit + $sb -> kreditJP) - ($sb -> debit + $sb -> debitJP) > 0)
                    <td>@currency(($sb -> kredit + $sb -> kreditJP) - ($sb -> debit + $sb -> debitJP))</td>
                    <input type="hidden" value="{{ $kredit_lap += ($sb -> kredit + $sb -> kreditJP) - ($sb -> debit + $sb -> debitJP)}}">
                    @else
                    <td>@currency(0)</td>
                    @endif

                    @endif

                </tr>

                @endforeach

                <tr>
                    <td><i><b>
                                <center>
                                    Jumlah Total
                                </center>
                            </b></i></td>
                    <td><i><b>@currency($debet_neraca)</b></i></td>
                    <td><i><b>@currency($kredit_neraca)</b></i></td>
                    <td><i><b>@currency($debet_ajp)</b></i></td>
                    <td><i><b>@currency($kredit_ajp)</b></i></td>
                    <td><i><b>@currency($debet_nssp)</b></i></td>
                    <td><i><b>@currency($kredit_nssp)</b></i></td>
                    <td><i><b>@currency($debet_laba)</b></i></td>
                    <td><i><b>@currency($kredit_laba)</b></i></td>
                    <td><i><b>@currency($debet_lap)</b></i></td>
                    <td><i><b>@currency($kredit_lap)</b></i></td>
                </tr>
                <tr>
                    @if(($kredit_laba - $debet_laba) > 0)
                    <td colspan="7"><i><b>Laba</b></i></td>
                    <td colspan="3"><i><b>@currency($kredit_laba - $debet_laba)</b></i></td>
                    <td colspan="3"><i><b>@currency($debet_lap - $kredit_lap)</b></i></td>
                    @else
                    <td colspan="7"><i><b>Rugi</b></i></td>
                    <td colspan="3"><i><b>@currency($kredit_laba - $debet_laba)</b></i></td>
                    <td colspan="3"><i><b>@currency($debet_lap - $kredit_lap)</b></i></td>
                    @endif
                </tr>
                <tr>
                    @if(($kredit_laba - $debet_laba) == ($debet_lap - $kredit_lap))
                    <td colspan="13">
                        <center>
                            <h1 style="color: dark;"><i>Balance</i></h1>
                        </center>
                    </td>
                    @else
                    <td colspan="13" style="color: white;">
                        <center>
                            <h1 style="color: dark;"><i>Tidak Balance</i></h1>
                        </center>
                    </td>
                    @endif
                </tr>
        </table>
    </div>
</div>

@endsection
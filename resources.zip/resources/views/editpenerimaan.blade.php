@extends('layout')
@section('penerimaan','active')
@section('content')
<!-- Default Basic Forms Start -->
<div class="pd-20 card-box mb-30">
    <div class="clearfix">
        <div class="pull-left">
            <h4 class="text-blue h4">Form Penerimaan</h4>
            <p class="mb-30">Tambahkan data Penerimaan </p>
        </div>
    </div>
    <form action="/form_penerimaan/update/{{$penerimaan->id_penerimaan}}" method="post" enctype="multipart/form-data">
        {{ csrf_field() }}
        <div class="form-group row">
            <label class="col-sm-12 col-md-2 col-form-label">Id Penerimaan</label>
            <div class="col-sm-12 col-md-10">
                <input class="form-control" type="text" name="id_penerimaan" value="{{$penerimaan->id_penerimaan}}">
            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-12 col-md-2 col-form-label">No Inventory</label>
            <div class="col-sm-12 col-md-10">
                <input class="form-control" type="text" name="no_inv" value="{{$penerimaan->no_inv}}">
            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-12 col-md-2 col-form-label">Junmlah Barang</label>
            <div class="col-sm-12 col-md-10">
                <input class="form-control" type="text" name="jumlah" value="{{$penerimaan->jml_barang}}">
            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-12 col-md-2 col-form-label">Total Harga</label>
            <div class="col-sm-12 col-md-10">
                <input class="form-control" type="text" name="total" value="{{$penerimaan->total_harga}}">
            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-12 col-md-2 col-form-label">Id_pegawai</label>
            <div class="col-sm-12 col-md-10">
                <input class="form-control" type="text" name="id_pegawai" value="{{$penerimaan->id_pegawai}}">
            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-12 col-md-2 col-form-label">No Supplier</label>
            <div class="col-sm-12 col-md-10">
                <input class="form-control" type="text" name="no_supplier" value="{{$penerimaan->no_supplier}}">
            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-12 col-md-2 col-form-label">Tanggal Penerimaan</label>
            <div class="col-sm-12 col-md-10">
                <input class="form-control" type="date" name="tanggal_penerimaan" value="{{$penerimaan->tanggal_penerimaan}}">
            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-12 col-md-2 col-form-label">Bukti Nota</label>
            <div class="col-sm-12 col-md-10">
                <input class="form-control" type="text" name="nota" value="{{$penerimaan->bukti_nota}}">
            </div>
        </div>
        <button type="submit" class="btn btn-primary btn-lg btn-block">Submit</button>
    </form>
</div>
<!-- Default Basic Forms End -->
@endsection
@extends('layout')
@section('pegawai','active')
@section('content')
<!-- Default Basic Forms Start -->
<div class="pd-20 card-box mb-30">
    <div class="clearfix">
        <div class="pull-left">
            <h4 class="text-blue h4">Data Pegawai</h4>
            <p class="mb-30">Edit Data Pegawai</p>
        </div>
    </div>
    <form action="/pegawai/{{$pegawai -> id_pegawai}}" method="post" enctype="multipart/form-data">
        {{ csrf_field() }}
        @method('put')
        <div class="form-group row">
            <label class="col-sm-12 col-md-2 col-form-label">Id Pegawai</label>
            <div class="col-sm-12 col-md-10">
                <input class="form-control" type="number" name="id_pegawai" value="{{$pegawai -> id_pegawai}}" readonly>
            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-12 col-md-2 col-form-label">Nama Lengkap</label>
            <div class="col-sm-12 col-md-10">
                <input class="form-control" type="text" name="nama" value="{{$pegawai -> nama_pegawai}}">
            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-12 col-md-2 col-form-label">Alamat</label>
            <div class="col-sm-12 col-md-10">
                <input class="form-control" type="text" name="alamat" value="{{$pegawai -> alamat_pegawai}}">
            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-12 col-md-2 col-form-label">Nomor Telpon</label>
            <div class="col-sm-12 col-md-10">
                <input class="form-control" type=text name="no_telpon" value="{{$pegawai -> no_telpon_pegawai}}">
            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-12 col-md-2 col-form-label">Tanggal lahir</label>
            <div class="col-sm-12 col-md-10">
                <input class="form-control date-picker" type="date" name="tgl_lahir" value="{{$pegawai -> tgl_lahir_pegawai}}">
            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-12 col-md-2 col-form-label">Tempat Lahir</label>
            <div class="col-sm-12 col-md-10">
                <input class="form-control" type="text" name="tempat_lahir" value="{{$pegawai -> tempat_lahir_pegawai}}">
            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-12 col-md-2 col-form-label">Divisi</label>
            <div class="col-sm-12 col-md-10">
                <input class="form-control" type="text" name="divisi" value="{{$pegawai -> divisi}}">
            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-12 col-md-2 col-form-label">Jabatan</label>
            <div class="col-sm-12 col-md-10">
                <input class="form-control" type="text" name="jabatan" value="{{$pegawai -> jabatan}}">
            </div>
        </div>
</div>
<button type="submit" class="btn btn-primary btn-lg btn-block">Submit</button>
</form>
</div>
<!-- Default Basic Forms End -->
@endsection
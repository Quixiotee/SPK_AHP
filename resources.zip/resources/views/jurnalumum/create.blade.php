@extends('layout')
@section('jurnalumum','active')
@section('content')

<!-- Default Basic Forms Start -->
<div class="pd-20 card-box mb-30">
    <div class="clearfix">
        <div class="pull-left">
            <h4 class="text-blue h4">Form Jurnal Umum</h4>
            <p class="mb-30">Tambahkan Data Jurnal Umum</p>
        </div>
    </div>
    <form action="/jurnalumum" method="post" enctype="multipart/form-data">
        {{ csrf_field() }}
        <div class="form-group row">
            <label class="col-sm-12 col-md-2 col-form-label">REF</label>
            <div class="col-sm-12 col-md-10">
                <select class="form-control" id="exampleFormControlSelect1" name="juRef">
                    @foreach($akun as $row)
                    <option value="{{$row->ref}}">{{$row->ref}}</option>
                    @endforeach
                </select>
            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-12 col-md-2 col-form-label">Keterangan</label>
            <div class="col-sm-12 col-md-10">
                <input class="form-control" type="text" name="juKet">
            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-12 col-md-2 col-form-label">Tanggal</label>
            <div class="col-sm-12 col-md-10">
                <input class="form-control" type="date" name="juTgl">
            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-12 col-md-2 col-form-label">Debet</label>
            <div class="col-sm-12 col-md-10">
                <input class="form-control" type="text" name="juDebet">
            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-12 col-md-2 col-form-label">Kredit</label>
            <div class="col-sm-12 col-md-10">
                <input class="form-control" type="text" name="juKredit">
            </div>
        </div>
        <button type="submit" class="btn btn-primary btn-lg btn-block">Submit</button>
    </form>
</div>
<!-- Default Basic Forms End -->
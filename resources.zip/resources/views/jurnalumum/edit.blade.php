@extends('layout')
@section('jurnalumum','active')
@section('content')

<!-- Default Basic Forms Start -->
<div class="pd-20 card-box mb-30">
    <div class="clearfix">
        <div class="pull-left">
            <h4 class="text-blue h4">Form Jurnal Umum</h4>
            <p class="mb-30">Tambahkan Data JUrnal Umum</p>
        </div>
    </div>
    <form action="/jurnalumum/{{$jurnal_umum->id}}" method="post" enctype="multipart/form-data">
        {{ csrf_field() }}
        @method("put")
        <input type="hidden" name="id" value="{{$jurnal_umum->id}}">
        <input type="hidden" name="name" value="{{$jurnal_umum->update_by}}">
        <div class="form-group row">
            <label class="col-sm-12 col-md-2 col-form-label">REF</label>
            <div class="col-sm-12 col-md-10">
                <select class="form-control" id="exampleFormControlSelect1" name="juRef">
                    @foreach($akun as $row)
                    <option value="{{$row->ref}}">{{$row->ref}}</option>
                    @endforeach
                </select>
            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-12 col-md-2 col-form-label">Keterangan</label>
            <div class="col-sm-12 col-md-10">
                <input class="form-control" type="text" name="juKet" value="{{$jurnal_umum->keterangan}}">
            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-12 col-md-2 col-form-label">Tanggal</label>
            <div class="col-sm-12 col-md-10">
                <input class="form-control" type="date" name="juTgl" value="{{$jurnal_umum->tanggal}}">
            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-12 col-md-2 col-form-label">Debet</label>
            <div class="col-sm-12 col-md-10">
                <input class="form-control" type="text" name="juDebet" value="{{$jurnal_umum->debet}}">
            </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-12 col-md-2 col-form-label">Kredit</label>
            <div class="col-sm-12 col-md-10">
                <input class="form-control" type="text" name="juKredit" value="{{$jurnal_umum->kredit}}">
            </div>
        </div>
        <button type="submit" class="btn btn-primary btn-lg btn-block">Submit</button>
    </form>
</div>
<!-- Default Basic Forms End -->
@endsection
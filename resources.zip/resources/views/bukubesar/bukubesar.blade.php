@extends('layout')
@section('content')

<div class="card-box mb-30">
    <div class="pd-20">
        <h4 class="text-blue h4">
            <center>Buku besar</center>
        </h4>
        <p>
            <center>Periode : {{$tgl_awal}} - {{$tgl_akhir}}</center>
        </p>
    </div>
    <br>
    <div class="nav-wrapper">
        <ul class="nav nav-pills nav-fill flex-column flex-md-row" id="tabs-icons-text" role="tablist">
            @foreach($data as $index=>$dt)
            <li class="nav-item">
                <a class="nav-link mb-sm-3 mb-md-0" id="tabs-icons-text-1-tab" data-toggle="tab" href="#y{{$dt->ref}}">{{$dt->nama}}</a>
            </li>
            @endforeach
        </ul>
    </div>
    <div class="card shadow pb-20">
        <div class="tab-content" id="myTabContent">
            @foreach($buku as $index=>$dt)
            <div class="tab-pane fade" id="y{{$dt->ref}}" role="tabpanel" aria-labelledby="tabs-icons-text-1-tab">
                <div class="pb-20 table-responsive">
                    <table class="data-table-export table">
                        <thead>
                            <tr>
                                <th scope="col" class="sort" data-sort="nama">Tanggal</th>
                                <th scope="col" class="sort" data-sort="nama">Debit</th>
                                <th scope="col" class="sort" data-sort="nama">Kredit</th>
                                <th scope="col" class="sort" data-sort="nama">Saldo Debit</th>
                                <th scope="col" class="sort" data-sort="nama">Saldo Kredit</th>
                            </tr>
                        </thead>

                        <tbody class="list">

                            @php
                            $debet = 0;
                            $kredit = 0;
                            $kredit2 = 0;
                            $kredit3 = 0;
                            $debet2 = 0;
                            $debet3 = 0;
                            $debet4 = 0;
                            $kredit4 = 0;
                            @endphp
                            @foreach($buku as $index=>$sb)
                            @if($dt->ref == $sb->ref)
                            <tr>

                                <td>{{ date('d M Y',strtotime($sb->tanggal)) }}</td>

                                <td> @currency($sb->debet)</td>
                                <td>@currency($sb->kredit)</td>
                                @if(($debet3 += $sb->debet) - ($kredit3 += $sb->kredit) > 0)
                                <td> @currency(($debet += $sb->debet) - ($kredit += $sb->kredit))</td>
                                @else
                                <td> @currency($sb->debet)</td>
                                @endif
                                @if(($kredit4 += $sb->kredit - $sb->debet) > 0)
                                <td>@currency($kredit2 += $sb->kredit - $sb->debet)</td>
                                @else
                                <td> @currency(0)</td>
                                @endif
                            </tr>
                            @endif
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
            @endforeach
        </div>
    </div>
</div>
</div>
</div>


@endsection

@section('scripts')

<script type="text/javascript">
    $(document).ready(function() {

        $('.btn-hapus').click(function(e) {
            e.preventDefault();
            var id = $(this).attr('sumber-id');
            var url = "{{ url('jurnal umum') }}" + '/' + id;
            $('#modal-notification').find('form').attr('action', url);
            $('#modal-notification').modal();
        })

    })
</script>

@endsection
@extends('layout')
@section('pembayaran','active')
@section('content')
<!-- Datatable start -->
<div class="card-box mb-30">
	<div class="pd-20">
		<h4 class="text-blue h4">Pembayaran Administrasi</h4>
		<a class="btn btn-dark" href="pembayaran/create">Create File</a>
	</div>
	<div class="pb-20">
		<table class="data-table-export table">
			<thead>
				<tr>
					<th>Id Pembayaran</th>
					<th class="datatable-nosort">Nama Peserta</th>
					<th class="datatable-nosort">Nama Diklat</th>
					<th class="datatable-nosort">Jumlah Pembayaran</th>
					<th class="datatable-nosort">Sisa Pembayaran</th>
                    <th class="datatable-nosort">Status</th>
					<th class="datatable-nosort">Created at</th>
					<th class="datatable-nosort">Update By</th>
					<th class="datatable-nosort">Action</th>
				</tr>
			</thead>
			<tbody>
            @foreach($pembayaran as $row)
				<tr>
					<td>{{ $row->id_pembayaran}}</td>
					<td>{{ $row->nama_peserta}}</td>
					<td>{{ $row->nama_diklat}}</td>
					<td>{{ $row->jumlah_pembayaran}}</td>
					<td>{{ $row->sisa_pembayaran}}</td>
                    <td>{{ $row->status}}</td>
					<td>{{ $row->created_at}}</td>
					<td>{{ $row->update_by}}</td>
					<td>
						<div class="dropdown">
							<a class="btn btn-link font-24 p-0 line-height-1 no-arrow dropdown-toggle" href="#" role="button" data-toggle="dropdown">
								<i class="dw dw-more"></i>
							</a>
							<div class="dropdown-menu dropdown-menu-right dropdown-menu-icon-list">
								<a class="dropdown-item" href="/pembayaran/{{$row->id_pembayaran}}/edit"><i class="dw dw-edit2"></i> Edit</a>
							</div>
						</div>
					</td>
				</tr>
				@endforeach
			</tbody>
		</table>
	</div>
</div>
<!-- Datatable End -->
@endsection
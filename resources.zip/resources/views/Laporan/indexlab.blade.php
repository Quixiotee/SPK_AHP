@extends('layout')
@section('content')

<div class="card-box mb-30">
    <div class="pd-20"> 
        <h4 class="text-blue h4">Pilih Periode Laporan Laba Rugi</h4>
    </div>
    <div class="pb-20">
      <form action="{{ '/labarugi/laporan' }}" method="get">
                @csrf
                <div class="form-group mt-3 row">
                    <label class="col-sm-12 col-md-2 col-form-label">Tanggal Awal</label>
                    <div class="col-sm-12 col-md-10">
                        <input type="date" name="tgl_awal">
                    </div>
                </div>
                <div class="form-group mt-3 row">
                    <label class="col-sm-12 col-md-2 col-form-label">Tanggal Akhir</label>
                    <div class="col-sm-12 col-md-10">
                        <input type="date" name="tgl_akhir">
                    </div>
                </div>
                <div class="text-center">
                    <button type="submit" class="btn btn-primary">Pilih</button>
                </div>
        </form>
    </div>
</div>
@endsection

@section('scripts')

<script type="text/javascript"> 
  $(document).ready(function() {

    $('.btn-hapus').click(function(e) {
      e.preventDefault();
      var id = $(this).attr('sumber-id');
      var url = "{{ url('jurnal umum') }}" + '/' + id;
      $('#modal-notification').find('form').attr('action', url);

      $('#modal-notification').modal();
    })

  })
</script>

@endsection


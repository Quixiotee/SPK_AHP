@extends('layout')
@section('content')

<div class="card-box mb-30">
    <div class="pd-20">
        <h2>
            <center>PT. Perwita Maritim Persadha</center>
        </h2>
        <h4 class="text-blue h4">
            <center>Laporan Perubahan Modal</center>
        </h4>
        <p>
            <center>Periode : {{$tgl_awal}} - {{$tgl_akhir}}</center>
        </p>
    </div>
    <div class="pb-20 pb-20 table-responsive">
        <table class="data-table-export table">
            <thead>
                <tr>
                    <th scope="col" class="sort" data-sort="nama">Nama Ref</th>
                    <th scope="col" class="sort" data-sort="nama">Debet</th>
                    <th scope="col" class="sort" data-sort="nama">kredit</th>

                </tr>
            </thead>
            <tbody class="list">
                @php
                $debet = 0;
                $kredit = 0;
                $prive = 0;
                $prived = 0;
                $privek = 0;
                $modal2 = 0;
                $modal2d = 0;
                $modal2k = 0;
                $aktivald = 0;
                $aktivalk = 0;
                $aktivatd = 0;
                $aktivatk = 0;
                $pasivad = 0;
                $pasivak = 0;
                @endphp
                @foreach($data as $index=>$sb)
                <tr>

                    @if(($sb->ref == '300') || ($sb->ref == '312') || ($sb->ref == '311') || ($sb->ref == '301') || ($sb->ref == '303') || ($sb->ref == '302') || ($sb->ref == '304') || ($sb->ref == '305') || ($sb->ref == '306') || ($sb->ref == '307') || ($sb->ref == '308') || ($sb->ref == '309') || ($sb->ref == '310'))
                    <td> {{$sb->nama}} </td>
                    @if(($sb -> debit + $sb -> debitJP) - ($sb -> kredit + $sb -> kreditJP) > 0)
                    <td> @currency(($sb -> debit + $sb -> debitJP) - ($sb -> kredit + $sb -> kreditJP))</td>
                    @else
                    <td> @currency(0)</td>
                    @endif
                    @if(($sb -> kredit + $sb -> kreditJP) - ($sb -> debit + $sb -> debitJP) > 0)
                    <td> @currency(($sb -> kredit + $sb -> kreditJP) - ($sb -> debit + $sb -> debitJP))</td>

                    @else
                    <td>@currency(0)</td>
                    @endif
                    @endif


                    @if($sb->ref == '311')
                    @if(($sb -> debit + $sb -> debitJP) - ($sb -> kredit + $sb -> kreditJP) > 0)
                    <input type="hidden" value="{{ $modal2d = ($sb -> debit + $sb -> debitJP) - ($sb -> kredit + $sb -> kreditJP)}}">
                    @else
                    <input type="hidden" name="" value="{{ $modal2d = 0 }}">
                    @endif
                    @if(($sb -> kredit + $sb -> kreditJP) - ($sb -> debit + $sb -> debitJP) > 0)
                    <input type="hidden" value="{{ $modal2k = ($sb -> kredit + $sb -> kreditJP) - ($sb -> debit + $sb -> debitJP) }}">
                    @else
                    <input type="hidden" name="" value="{{ $modal2k = 0 }}">
                    @endif
                    @elseif($sb->ref == '312')
                    @if(($sb -> debit + $sb -> debitJP) - ($sb -> kredit + $sb -> kreditJP) > 0)
                    <input type="hidden" value="{{ $prived = ($sb -> debit + $sb -> debitJP) - ($sb -> kredit + $sb -> kreditJP)}}">
                    @else
                    <input type="hidden" name="" value="{{ $prived = 0 }}">
                    @endif
                    @if(($sb -> kredit + $sb -> kreditJP) - ($sb -> debit + $sb -> debitJP) > 0)
                    <input type="hidden" value="{{ $privek = ($sb -> kredit + $sb -> kreditJP) - ($sb -> debit + $sb -> debitJP) }}">
                    @else
                    <input type="hidden" name="" value="{{ $privek = 0 }}">
                    @endif
                    @endif

                </tr>
                @endforeach
                <tr>
                    @if(($kredit - $debet) > 0)
                    <td>Laba bersih</td>
                    <td>@currency(0)</td>
                    <td>@currency($kredit - $debet)</td>
                    @else
                    <td>Rugi</td>
                    <td>@currency($debet - $kredit)</td>
                    <td>@currency(0)</td>
                    @endif
                </tr>

                <tr>
                    @if(($kredit - $debet) > 0)
                    <td>Penambahan Modal</td>
                    <td>@currency(0)</td>
                    <td>@currency(($kredit - $debet) - ($prived + $privek))</td>
                    @else
                    <td>Pengurangan Modal</td>
                    <td>@currency($debet - $kredit + $prive)</td>
                    <td>@currency(0)</td>
                    @endif
                </tr>
                <tr>
                    @if(($kredit - $debet) > 0)
                    <td colspan="2"><i><b>
                                <center>
                                    Modal Akhir
                                </center>
                            </b></i></td>
                    <td><i><b>
                                @currency((($kredit - $debet) - ($prived + $privek)) + ($modal2d + $modal2k))
                            </b></i></td>
                    @else
                    <td></td>
                    <td><i><b>
                                <center>
                                    Modal Akhir
                                </center>
                            </b></i></td>
                    <td><i><b>
                                @currency(($modal2d + $modal2k) - (($debet - $kredit) + ($prived + $privek)))
                            </b></i></td>
                    @endif
                </tr>
            </tbody>
        </table>
    </div>
</div>
</div>
@endsection
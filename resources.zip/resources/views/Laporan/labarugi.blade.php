@extends('layout')
@section('content')

<div class="card-box mb-30">
    <div class="pd-20">
        <h2>
            <center>PT. Perwita Maritim Persadha</center>
        </h2>
        <h4 class="text-blue h4">
            <center>Laporan Laba Rugi</center>
        </h4>
        <p>
            <center>Periode : {{$tgl_awal}} - {{$tgl_akhir}}</center>
        </p>
    </div>
    <div class="pb-20 pb-20 table-responsive">
        <table class="data-table-export table">
            <thead>
                <tr>
                    <th scope="col" class="sort" data-sort="nama">No. Ref</th>
                    <th scope="col" class="sort" data-sort="nama">Nama Ref</th>
                    <th scope="col" class="sort" data-sort="nama">Debet</th>
                    <th scope="col" class="sort" data-sort="nama">Kredit</th>
                </tr>
            </thead>
            <tbody class="list">
                @php
                $debet = 0;
                $kredit = 0;
                $prive = 0;
                $prived = 0;
                $privek = 0;
                $modal2 = 0;
                $modal2d = 0;
                $modal2k = 0;
                $aktivald = 0;
                $aktivalk = 0;
                $aktivatd = 0;
                $aktivatk = 0;
                $pasivad = 0;
                $pasivak = 0;
                @endphp
                @foreach($data as $index=>$sb)

                <tr>

                    @if((($sb->ref == '500') || ($sb->ref == '510') || ($sb->ref == '511')|| ($sb->ref == '512') || ($sb->ref == '513')|| ($sb->ref == '514') || ($sb->ref == '515') || ($sb->ref == '516') || ($sb->ref == '517')|| ($sb->ref == '518')|| ($sb->ref == '519')|| ($sb->ref == '520')) || (($sb->ref == '400') || ($sb->ref == '410') || ($sb->ref == '411')|| ($sb->ref == '412') || ($sb->ref == '413') || ($sb->ref == '414') || ($sb->ref == '415')))

                    <td> {{ $sb->ref }}</td>
                    <td> {{ $sb->nama }}</td>
                    @if(($sb -> debit + $sb -> debitJP) - ($sb -> kredit + $sb -> kreditJP) > 0)
                    <td> @currency(($sb -> debit + $sb -> debitJP) - ($sb -> kredit + $sb -> kreditJP))</td>
                    <input type="hidden" value="{{ $debet += ($sb -> debit + $sb -> debitJP) - ($sb -> kredit + $sb -> kreditJP)}}">
                    @else
                    <td> @currency(0)</td>
                    @endif

                    @if(($sb -> kredit + $sb -> kreditJP) - ($sb -> debit + $sb -> debitJP) > 0)
                    <td>@currency(($sb -> kredit + $sb -> kreditJP) - ($sb -> debit + $sb -> debitJP))</td>
                    <input type="hidden" value="{{ $kredit += ($sb -> kredit + $sb -> kreditJP) - ($sb -> debit + $sb -> debitJP)}}">
                    @else
                    <td>@currency(0)</td>
                    @endif
                    @endif

                </tr>
                @endforeach
                <tr>
                    @if(($kredit - $debet) > 0)
                    <td colspan="2"><i><b>
                                <center>
                                    Jumlah Total
                                </center>
                            </b></i></td>
                    <td></td>
                    <td><i><b>
                                @currency($kredit - $debet)
                            </b></i></td>
                    @else
                    <td></td>
                    <td></td>
                    <td><i><b>
                                <center>
                                    Jumlah Total
                                </center>
                            </b></i></td>
                    <td><i><b>
                                @currency($kredit - $debet)
                            </b></i></td>
                    @endif
                </tr>

                <tr>
                    <td colspan="4">
                        @if(($kredit - $debet) > 0 )
                        <center>
                            <h1 style="color: dark;"><b><i>Laba</i></b></h1>
                        </center>

                        @else
                        <center>
                            <h1 style="color: dark;"><b><i>Rugi</i></b></h1>
                        </center>
                        @endif
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</div>

@endsection

@extends('layout')
@section('content')

<!-- Datatable start -->
<div class="card-box mb-30">
    <div class="pd-20">
        <h4 class="text-blue h4">Akun</h4>
        <button class="btn btn-primary">
            <a href="akun/create" style="color:#FFF">Create File</a>
        </button>
        <button class="btn btn-primary">
            <a href="/akunexport" style="color:#FFF">Export</a>
        </button>
        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
            Import
        </button>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <form action="/akunimport" enctype="multipart/form-data" method="post">
                    @csrf
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Masukan Data</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <input type="file" name="file" id="">
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Import</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- End Modal -->



<div class="pb-20">
    <table class="data-table-export table ">
        <thead>
            <tr>
                <th scope="col" class="sort" data-sort="nama">REF</th>
                <th scope="col" class="sort" data-sort="nama">Nama Akun</th>
                <th scope="col" class="sort" data-sort="nama">Log Activity</th>
                <th scope="col" class="no-sort" data-sort="">Aksi</th>
            </tr>
        </thead>
        <tbody>
            @foreach($akun as $row)
            <tr>
                <td>{{ $row->ref}}</td>
                <td>{{ $row->nama}}</td>
                <td>{{ $row->update_by}}</td>
                <td>
                    <div class="dropdown">
                        <a class="btn btn-link font-24 p-0 line-height-1 no-arrow dropdown-toggle" href="#" role="button" data-toggle="dropdown">
                            <i class="dw dw-more"></i>
                        </a>
                        <div class="dropdown-menu dropdown-menu-right dropdown-menu-icon-list">
                            <a class="dropdown-item" href="/akun/{{$row->ref}}/edit"><i class="dw dw-edit2"></i> Edit</a>
                            <form action="akun/{{$row->ref}}" method="post">
                                @csrf
                                @method('delete')
                                <button class="dropdown-item"><i class="dw dw-delete-3"></i> Delete</button>
                            </form>
                        </div>
                    </div>
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>
</div>
</div>
</div>
<!-- Datatable End -->
@endsection